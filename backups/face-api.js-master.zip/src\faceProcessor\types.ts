import { FCParams } from '../common';

export type NetParams = {
  fc: FCParams
}

